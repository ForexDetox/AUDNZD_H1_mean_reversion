from pathlib import Path
import sys,json
sys.path.insert(0,str(Path('work/python_libs').resolve()))
import numpy as np,pandas as pd
O=Path('outputs/strategy_test/window8_MA_2bp');rank=pd.read_csv(O/'same_top10_fixed_order.csv');eq=pd.read_csv(O/'top10_daily_equity.csv',index_col=0,parse_dates=True);ledger=pd.read_csv(O/'top10_trade_ledger.csv')
assert np.all(np.diff(eq.index.as_unit('ns').asi8)==86400*10**9)
rows=[]
for _,v in rank.iterrows():
 col=f'{v["rank"]}. {v["filter"]}(8), MA';e=eq[col];r=e.pct_change().dropna();sd=r.std(ddof=1);down=np.sqrt(np.mean(np.minimum(r,0)**2));tr=ledger[ledger['filter']==v['filter']].sort_values('entry_time');pnl=tr.net_pnl_NZD
 assert len(tr)==v.trades and np.isclose(e.iloc[-1],v.final_equity_NZD)
 assert np.isclose(10000+pnl.sum(),e.iloc[-1])
 assert np.isclose(np.prod(1+pnl/tr.equity_before_NZD),e.iloc[-1]/10000)
 peak=np.maximum.accumulate(np.r_[10000,e.to_numpy()])[1:];dd=e.to_numpy()/peak-1
 days=0;maxdays=0
 for x in dd:
  days=days+1 if x < -1e-12 else 0;maxdays=max(maxdays,days)
 holds=(pd.to_datetime(tr.exit_time)-pd.to_datetime(tr.entry_time)).dt.total_seconds()/3600
 rows.append(dict(rank=int(v['rank']),filter=v['filter'],CAGR_pct=v.net_cagr_pct,MDD_hourly_pct=v.max_drawdown_hourly_pct,Sharpe=r.mean()/sd*np.sqrt(365.25),Sortino=r.mean()/down*np.sqrt(365.25),Calmar=v.net_cagr_pct/v.max_drawdown_hourly_pct,annual_volatility_pct=sd*np.sqrt(365.25)*100,total_return_pct=v.net_return_pct,trades=len(tr),win_rate_pct=(pnl>0).mean()*100,profit_factor=pnl[pnl>0].sum()/(-pnl[pnl<0].sum()),avg_net_pips=v.net_mean_pips,mean_trade_return_pct=(pnl/tr.equity_before_NZD).mean()*100,median_hold_hours=holds.median(),MDD_daily_pct=-dd.min()*100,max_underwater_calendar_days=maxdays,final_equity_NZD=e.iloc[-1]))
d=pd.DataFrame(rows);d.to_csv(O/'performance_statistics.csv',index=False)
cols=['filter','CAGR_pct','MDD_hourly_pct','Sharpe','Sortino','Calmar','trades','win_rate_pct','profit_factor']
lines=['| Filter (8) | CAGR | MDD | Sharpe | Sortino | Calmar | Trades | Win rate | Profit factor |','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for _,v in d.iterrows():lines.append(f'| {v["filter"]} | {v.CAGR_pct:.2f}% | {v.MDD_hourly_pct:.2f}% | {v.Sharpe:.2f} | {v.Sortino:.2f} | {v.Calmar:.2f} | {int(v.trades)} | {v.win_rate_pct:.1f}% | {v.profit_factor:.2f} |')
notes='''Same ten filters in the original order; window 8; MA exit; 2% price-to-stop risk; 2 bp entry-notional round-trip cost. April 1, 2021 through November 1, 2026.\n\nCAGR uses elapsed calendar years from April 1, 2021 to November 2, 2026. MDD is positive loss magnitude from hourly-close marked equity, carried over from the verified backtest; intrabar losses may be greater. Sharpe is mean calendar-daily simple return divided by sample standard deviation, multiplied by sqrt(365.25), assuming zero risk-free return. Sortino uses zero minimum acceptable return and downside deviation sqrt(mean(min(daily_return,0)^2)), using every daily observation in the denominator, multiplied by sqrt(365.25). Calendar days, including flat weekends/nontrading days, are retained. These are conventional annualized descriptive ratios without serial-correlation adjustment. Calmar = CAGR / hourly-close MDD. Win rate counts strictly positive net trade P&L. Profit factor = sum of positive net NZD trade P&L divided by absolute negative net NZD trade P&L, with variable compounded position sizes. Costs are deducted at exit. Trade returns use each trade's starting net equity. Full-period strategy selection remains in-sample.\n\nVerified all ten final balances against the existing curves and rankings, cash-P&L reconciliation and compounded per-trade returns.'''
(O/'performance_statistics.md').write_text('\n'.join(lines)+'\n\n'+notes,encoding='utf-8');print('\n'.join(lines))
