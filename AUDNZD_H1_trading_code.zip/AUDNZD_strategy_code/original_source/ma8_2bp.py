from pathlib import Path
s=Path('work/ma8_curves.py').read_text(encoding='utf-8')
s=s.replace("b.O/'window8_MA_1bp'","b.O/'window8_MA_2bp'")
s=s.replace('cost=.0001*start*units','cost=.0002*start*units').replace('R-.0001*start/distance','R-.0002*start/distance').replace('netpips.append(pips-start)','netpips.append(pips-2*start)')
s=s.replace("top=d.drop_duplicates('trade_fingerprint').head(10).copy();top.insert(0,'rank',range(1,11));top.to_csv(O/'top10_distinct.csv',index=False)","fixed=pd.read_csv(b.O/'window8_MA_1bp/top10_distinct.csv')[['rank','filter','exit_rule']];top=fixed.merge(d,on=['filter','exit_rule'],validate='one_to_one').sort_values('rank');top.to_csv(O/'same_top10_fixed_order.csv',index=False)")
s=s.replace('1 bp','2 bp').replace('Ranked by net return','Same selection and order as the 1 bp chart').replace('selected in sample from 34 filters with MA exit','selected at 1 bp; same ranking retained at 2 bp')
s=s.replace('Ranked by compounded net return; no independent validation.','Original 1 bp top ten and ordering retained; no independent validation.').replace('Exact duplicate gross trade histories removed from plotted top ten; literal ranking also supplied.','Exact duplicate gross trade histories were removed in the original selection. Current-cost all-filter ranking is also supplied separately.')
exec(compile(s,'ma8_2bp_generated','exec'))
