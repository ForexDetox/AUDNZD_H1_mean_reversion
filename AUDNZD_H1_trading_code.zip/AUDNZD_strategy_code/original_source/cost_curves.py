import strategy_test as b
import pandas as pd,numpy as np,json,zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=b.O/'cost_1bp';O.mkdir(exist_ok=True)
leaders=pd.read_csv(b.O/'best_each_exit.csv');ledger=pd.read_csv(b.O/'selected_trade_ledger.csv');rows=[];records=[];curves={}
years=(pd.Timestamp('2026-11-02',tz='UTC')-pd.Timestamp('2021-04-01',tz='UTC')).total_seconds()/(365.25*86400)
for _,r in leaders.iterrows():
 t=ledger[(ledger['filter']==r['filter'])&(ledger.length==r.length)&(ledger.exit_rule==r.exit_rule)].copy()
 assert len(t)==r.trades
 eq=np.full(b.N,10000.);balance=10000.;cursor=0;factors=[];fees=0
 for _,v in t.iterrows():
  entry=b.idx.get_loc(pd.Timestamp(v.entry_time));j=b.idx.get_loc(pd.Timestamp(v.exit_bar));side=1 if v.direction=='long' else -1;distance=v.stop_distance_pips/10000;units=.02*balance/distance;cost=.0001*v.entry_price*units;gross=units*side*(v.exit_price-v.entry_price);after=balance+gross-cost
  assert np.isclose(gross/balance,.02*v.R)
  factors.append(1+.02*(v.R-.0001*v.entry_price/distance))
  eq[cursor:entry]=balance;eq[entry:j+1]=balance+units*side*(b.cl[entry:j+1]-v.entry_price);eq[j]=after;cursor=j+1
  records.append(dict(filter=r['filter'],length=r.length,exit_rule=r.exit_rule,entry_time=v.entry_time,exit_time=v.exit_time,equity_before_NZD=balance,units_AUD=units,entry_notional_NZD=units*v.entry_price,cost_NZD=cost,gross_pnl_NZD=gross,net_pnl_NZD=gross-cost,equity_after_NZD=after))
  fees+=cost;balance=after
 eq[cursor:]=balance
 assert np.isclose(balance,10000*np.prod(factors))
 assert np.isclose(10000*np.prod(1+.02*t.R.to_numpy()),r.final_equity_NZD)
 start=b.idx.searchsorted('2021-04-01');series=pd.Series(eq[start:],index=b.idx[start:]+pd.Timedelta(hours=1));daily=series.resample('D').last().ffill();dd=series/np.maximum.accumulate(np.r_[10000,series.to_numpy()])[1:]-1
 label=f'{r.exit_rule}: {r["filter"]}({int(r.length)})';curves[label]=daily
 rows.append(dict(exit_rule=r.exit_rule,filter=r['filter'],length=r.length,trades=len(t),gross_return_pct=r.total_return_pct,net_return_pct=(balance/10000-1)*100,net_cagr_pct=((balance/10000)**(1/years)-1)*100,hourly_close_max_drawdown_pct=-dd.min()*100,final_equity_NZD=balance,total_cost_NZD=fees,mean_cost_pips=t.entry_price.mean(),net_mean_pips=(t.pips-t.entry_price).mean()))
pd.DataFrame(rows).to_csv(O/'summary.csv',index=False);pd.DataFrame(records).to_csv(O/'cost_adjusted_trade_ledger.csv',index=False);pd.DataFrame(curves).to_csv(O/'daily_equity.csv')
plt.rcParams.update({'font.size':10});fig,axes=plt.subplots(2,1,figsize=(12,8),sharex=True)
for label,series in curves.items():
 axes[0].plot(series.index,series,label=label);draw=series/np.maximum.accumulate(np.r_[10000,series.to_numpy()])[1:]-1;axes[1].plot(series.index,draw*100)
axes[0].set_yscale('log');axes[0].set_ylabel('Equity in NZD (log scale)');axes[0].legend(fontsize=8);axes[1].set_ylabel('Daily-close drawdown (%)');axes[1].set_xlabel('UTC date');fig.suptitle('AUDNZD: same five strategies, with 1 bp round-trip cost\nTue–Thu, 17–21 signal labels | 2% risk, 2×ATR stop | NZD 10,000 initial equity')
for ax in axes:ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(O/'equity_curves_1bp.png',dpi=160);plt.close(fig)
(O/'methodology.md').write_text('Same five gross-selected strategies and exact trades as the previous test; no reselection and no filter recalculation. Period April 2021–November 1, 2026. One basis point means 0.01% of entry traded notional per completed round trip, charged at exit. This is approximately 1.0–1.25 AUDNZD pips depending on entry price, not 1 bp of account equity and not 1 bp per side. No other costs added. Position sizes are recomputed after each net result: units=2% of current net equity / original stop distance. Consequently the 2% price-to-stop risk excludes fees; a stop loss plus cost exceeds 2%. Account is NZD; fractional sizes and uncapped leverage retained. Trade paths, causal signals, ATR stops and moving-average exit rules remain as previously documented. Open positions marked at each H1 close with costs debited on exit. Chart drawdowns use daily closes; summary drawdowns use hourly closes and can differ. Intrabar drawdowns can be greater. Historical selection remains in-sample. Independently verified final equity by product of per-trade net return factors and reproduced all five prior zero-cost final equities.',encoding='utf-8')
with zipfile.ZipFile(O/'AUDNZD_1bp_results.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in O.iterdir():
  if f.suffix in ['.csv','.md','.png']:z.write(f,f.name)
print(pd.DataFrame(rows).to_string(index=False))
