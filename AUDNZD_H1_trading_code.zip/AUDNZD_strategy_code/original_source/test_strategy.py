import strategy_test as b
import numpy as np
original={k:getattr(b,k) for k in ['N','ns','op','hi','lo','cl','at']}
def fixture():
 b.N=5;b.ns=np.arange(5,dtype=np.int64)*b.hour;b.op=np.array([100.,100.,101.,102.,103.]);b.hi=b.op+.4;b.lo=b.op-.4;b.cl=b.op+.1;b.at=np.ones(5)
 return np.ones(5)*104,np.array([1,0,0,0,0])
ma,s=fixture();r,t=b.simulate(ma,s,1);assert t[0][5]==101 and t[0][7]==.5 and t[0][10]==10100
ma,s=fixture();b.lo[1]=97;r,t=b.simulate(ma,s,1);assert t[0][12]=='stop' and t[0][7]==-1 and t[0][10]==9800
ma,s=fixture();b.op[2]=97;r,t=b.simulate(ma,s,1);assert t[0][12]=='gap_stop' and t[0][7]==-1.5
ma,s=fixture();ma[0]=101;ma[1]=500;b.hi[1]=101.2;r,t=b.simulate(ma,s,0);assert t[0][5]==101 and t[0][12]=='ma_touch'
ma,s=fixture();ma[0]=101;b.hi[1]=102;b.lo[1]=97;r,t=b.simulate(ma,s,0);assert t[0][12]=='stop' and t[0][13]==1
ma,s=fixture();s[0]=-1;b.op[2]=99;r,t=b.simulate(ma,s,1);assert t[0][7]==.5
for k,v in original.items():setattr(b,k,v)
ma=b.get_ma('SUPERSMOOTHER',18);base=b.signals(ma);cut=b.idx.searchsorted('2024-01-01');changed=ma.copy();changed[cut:]+=10;new=b.signals(changed);assert np.array_equal(base[:cut],new[:cut])
assert not base[:b.idx.searchsorted('2021-04-01')].any()
print('PASS: timed exit, long/short P&L, stop risk, gap loss, lagged MA target, ambiguous stop priority, future-invariance and warm-up.')
