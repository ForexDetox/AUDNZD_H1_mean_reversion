import strategy_test as b
import numpy as np,pandas as pd,json,zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=b.O/'window8_MA_1bp';O.mkdir(exist_ok=True)
records=[];curves={};trades=[]
years=(pd.Timestamp('2026-11-02',tz='UTC')-pd.Timestamp('2021-04-01',tz='UTC')).total_seconds()/(365.25*86400)
prior=pd.read_csv(b.O/'all_rankings.csv');prior=prior[prior.length==8]
for method in sorted(prior['filter'].unique()):
 ma=b.get_ma(method,8);s=b.signals(ma)
 for h in [0]:
  gross,ts=b.simulate(ma,s,h);rule=gross['exit_rule'];old=prior[(prior['filter']==method)&(prior.exit_rule==rule)].iloc[0];assert np.isclose(gross['final_equity_NZD'],old.final_equity_NZD)
  eq=np.full(b.N,10000.);balance=10000.;cursor=0;factors=[];netpips=[]
  for v in ts:
   signal,entry,j,side,start,price,distance,R,pips,_,_,exit_ns,reason,ambiguous,leverage=v
   units=.02*balance/distance;cost=.0001*start*units;profit=units*side*(price-start)-cost;after=balance+profit
   factors.append(1+.02*(R-.0001*start/distance));netpips.append(pips-start)
   eq[cursor:entry]=balance;eq[entry:j+1]=balance+units*side*(b.cl[entry:j+1]-start);eq[j]=after;cursor=j+1
   trades.append(dict(filter=method,length=8,exit_rule=rule,entry_time=b.idx[entry],exit_time=pd.Timestamp(exit_ns,tz='UTC'),side=side,entry_price=start,exit_price=price,units_AUD=units,cost_NZD=cost,net_pnl_NZD=profit,equity_before_NZD=balance,equity_after_NZD=after,exit_reason=reason))
   balance=after
  eq[cursor:]=balance;assert np.isclose(balance,10000*np.prod(factors))
  begin=b.idx.searchsorted('2021-04-01');series=pd.Series(eq[begin:],index=b.idx[begin:]+pd.Timedelta(hours=1));dd=series/np.maximum.accumulate(np.r_[10000,series.to_numpy()])[1:]-1
  key=method+' / '+rule;curves[key]=series.resample('D').last().ffill()
  records.append(dict(filter=method,length=8,exit_rule=rule,trades=len(ts),net_return_pct=(balance/10000-1)*100,net_cagr_pct=((balance/10000)**(1/years)-1)*100,max_drawdown_hourly_pct=-dd.min()*100,net_mean_pips=np.mean(netpips),final_equity_NZD=balance,trade_fingerprint=gross['trade_fingerprint']))
d=pd.DataFrame(records).sort_values(['net_return_pct','filter','exit_rule'],ascending=[False,True,True]);d.to_csv(O/'all_34_MA_rankings.csv',index=False);d.head(10).to_csv(O/'top10_literal.csv',index=False)
top=d.drop_duplicates('trade_fingerprint').head(10).copy();top.insert(0,'rank',range(1,11));top.to_csv(O/'top10_distinct.csv',index=False)
ledger=pd.DataFrame(trades).merge(top[['filter','exit_rule']],on=['filter','exit_rule']);ledger.to_csv(O/'top10_trade_ledger.csv',index=False)
selected={f'{r["rank"]}. {r["filter"]}(8), {r.exit_rule}':curves[r['filter']+' / '+r.exit_rule] for _,r in top.iterrows()};pd.DataFrame(selected).to_csv(O/'top10_daily_equity.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
fig,axes=plt.subplots(2,1,figsize=(13,9),sharex=True,gridspec_kw={'height_ratios':[2,1]});colors=plt.get_cmap('tab10').colors
for i,(label,series) in enumerate(selected.items()):
 style='-' if i<5 else '--';axes[0].plot(series.index,series,color=colors[i],lw=1.7,ls=style,label=label);draw=series/np.maximum.accumulate(np.r_[10000,series.to_numpy()])[1:]-1;axes[1].plot(series.index,draw*100,color=colors[i],lw=1.1,ls=style)
axes[0].set_ylim(bottom=0);axes[0].yaxis.set_major_formatter(matplotlib.ticker.StrMethodFormatter('{x:,.0f}'));axes[0].set_ylabel('Equity in NZD (linear scale)');axes[0].legend(loc='upper left',ncol=2,fontsize=8.5,framealpha=.9);axes[1].set_ylabel('Daily-close drawdown (%)');axes[1].set_xlabel('UTC date')
for ax in axes:ax.grid(alpha=.2);ax.spines[['top','right']].set_visible(False)
fig.suptitle('AUDNZD: top 10 filters, MA exit, window length 8',fontsize=17)
fig.text(.5,.925,'Tue–Thu, 17–21 signal labels • 2% risk • 1 bp round-trip cost • Ranked by net return',ha='center',fontsize=11)
fig.text(.08,.018,'Same percentile-entry rules; 2×ATR(20) stop. Ten distinct trade histories selected in sample from 34 filters with MA exit.',fontsize=9)
fig.subplots_adjust(left=.08,right=.98,top=.88,bottom=.09,hspace=.12)
for ext in ['png','svg','pdf']:fig.savefig(O/f'AUDNZD_top10_MA_window8_linear.{ext}',dpi=200,facecolor='white')
plt.close(fig)
(O/'methodology.md').write_text('Restricted the saved price-filter window to 8 bars. Reused the established percentile-entry backtest, not the newly discussed ATR-deviation entry rule. All 34 filters were evaluated using the MA exit only (34 combinations). The target updates hourly to the previous completed bar’s saved filter value, with no fixed time limit. Stop takes precedence if both stop and target are touched in the same bar. Monthly entry thresholds use the preceding 12 months; entries are Tue–Thu 17–21 UTC opening labels, executed after close. Trading April 2021–November 1, 2026. Fixed 2×ATR(20) stop, 2% current net equity price-to-stop risk, and 1 bp of entry notional charged per round trip at exit. Stop risk excludes cost. ATR risk window remains 20; only price-filter window becomes 8. No other costs or leverage limits. Starting account NZD 10,000. Same execution assumptions as the prior backtest. Ranked by compounded net return; no independent validation. Exact duplicate gross trade histories removed from plotted top ten; literal ranking also supplied. Every plotted curve uses MA exit. The ten curves are independent strategies, not a combined portfolio. Table drawdowns use hourly closes, chart uses daily closes. Reproduced all 34 prior gross ending equities and independently verified all net compounding factors. Saved price filters were not recalculated.',encoding='utf-8')
with zipfile.ZipFile(O/'AUDNZD_MA_window8_results.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in O.iterdir():
  if f.suffix in ['.png','.svg','.pdf','.csv','.md']:z.write(f,f.name)
print(top.drop(columns='trade_fingerprint').to_string(index=False))
