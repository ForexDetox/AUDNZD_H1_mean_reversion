from pathlib import Path
driver=Path('work/ma8_2bp.py').read_text(encoding='utf-8')
driver=driver[:driver.index("exec(compile(s,")]
exec(driver)
s=s.replace("b.O/'window8_MA_2bp'","b.O/'window8_MA_2bp_revised'")
old="fixed=pd.read_csv(b.O/'window8_MA_1bp/top10_distinct.csv')[['rank','filter','exit_rule']]"
new="original=pd.read_csv(b.O/'window8_MA_1bp/all_34_MA_rankings.csv').sort_values(['net_return_pct','filter'],ascending=[False,True]).drop_duplicates('trade_fingerprint');fixed=original[original['filter']!='ALLAVERAGES_JMA'].head(10)[['filter','exit_rule']].copy();fixed.insert(0,'rank',range(1,11));assert fixed.iloc[-1]['filter']=='MCGINLEY'"
assert old in s;s=s.replace(old,new)
s=s.replace('Same selection and order as the 1 bp chart','Original ranking, replacing ALLAVERAGES_JMA with #11').replace('Ten distinct trade histories selected at 1 bp; same ranking retained at 2 bp','Selection at 1 bp; ALLAVERAGES_JMA replaced by McGinley (#11). Curves include 2 bp cost')
s=s.replace('Original 1 bp top ten and ordering retained;','Original 1 bp ordering retained, with ALLAVERAGES_JMA removed and original #11 MCGINLEY added;')
exec(compile(s,'replace_jma_generated','exec'))
stats=Path('work/performance_2bp.py').read_text(encoding='utf-8').replace("window8_MA_2bp'","window8_MA_2bp_revised'").replace('Same ten filters in the original order;','ALLAVERAGES_JMA replaced by original #11 MCGINLEY; remaining filters retain relative order;')
exec(compile(stats,'revised_performance','exec'))
