import strategy_test as b
import numpy as np,pandas as pd,json,zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
O=b.O;d=pd.read_csv(O/'all_rankings.csv');order=['1h','2h','4h','12h','MA'];rank=d.sort_values('total_return_pct',ascending=False)
distinct=rank.drop_duplicates(['exit_rule','trade_fingerprint']).groupby('exit_rule',sort=False).head(10)
keys=rank.drop_duplicates('trade_fingerprint').drop_duplicates(['filter','length']).head(10)[['filter','length']]
compar=d.merge(keys,on=['filter','length']);compar.to_csv(O/'top10_combinations_all_exits.csv',index=False)
matrix=compar.pivot(index=['filter','length'],columns='exit_rule',values='total_return_pct')[order]
matrix=matrix.loc[pd.MultiIndex.from_frame(keys)]
fig,ax=plt.subplots(figsize=(10,7));im=ax.imshow(matrix.to_numpy(),cmap='YlGnBu',aspect='auto');ax.set_xticks(range(5),order);ax.set_yticks(range(10),[f'{m}({l})' for m,l in matrix.index]);ax.set_xlabel('Exit rule');ax.set_title('Top ten filter/window combinations: same settings, five exits\nTotal compounded return (%) | 2% risk per trade | zero costs')
for i in range(10):
 for j in range(5):
  v=matrix.iloc[i,j];ax.text(j,i,f'{v:,.0f}%',ha='center',va='center',color='white' if v>matrix.to_numpy().max()*.6 else 'black')
fig.colorbar(im,ax=ax,label='Total return (%)');fig.tight_layout();fig.savefig(O/'top10_exit_heatmap.png',dpi=160);plt.close(fig)
selected=pd.concat([distinct,compar]).drop_duplicates(['filter','length','exit_rule'])
trades=[];curves={};verified=[];rows=[];yearrows=[]
for _,r in selected.iterrows():
 ma=b.get_ma(r['filter'],int(r.length));s=b.signals(ma);h=0 if r.exit_rule=='MA' else int(r.exit_rule[:-1]);stats,ts=b.simulate(ma,s,h)
 assert np.isclose(stats['final_equity_NZD'],r.final_equity_NZD)
 eq=np.full(b.N,10000.);cursor=0
 for t in ts:
  signal,entry,j,side,start,price,distance,R,pips,before,after,exit_ns,reason,ambiguous,leverage=t
  assert signal<entry and b.ns[entry]-b.ns[signal]==b.hour
  assert b.eligible[signal] and np.isfinite(ma[signal])
  assert np.isclose(after,before*(1+.02*R))
  assert np.isclose(R,side*(price-start)/distance)
  eq[cursor:entry]=before
  eq[entry:j+1]=before*(1+.02*side*(b.cl[entry:j+1]-start)/distance)
  eq[j]=after;cursor=j+1
  trades.append(dict(filter=r['filter'],length=r.length,exit_rule=r.exit_rule,signal_time=b.idx[signal],signal_close=b.cl[signal],signal_filter_value=ma[signal],signal_deviation_pips=(b.cl[signal]-ma[signal])*10000,entry_time=b.idx[entry],exit_bar=b.idx[j],exit_time=pd.Timestamp(exit_ns,tz='UTC'),direction='long' if side==1 else 'short',entry_price=start,exit_price=price,stop_level=start-side*distance,stop_distance_pips=distance*10000,R=R,pips=pips,equity_before=before,equity_after=after,units_AUD=before*.02/distance,exit_reason=reason,ambiguous_stop_target=ambiguous,entry_leverage=leverage))
 eq[cursor:]=ts[-1][10] if ts else 10000
 startidx=b.idx.searchsorted('2021-04-01');eq=eq[startidx:];dates=b.idx[startidx:]+pd.Timedelta(hours=1);draw=eq/np.maximum.accumulate(np.r_[10000,eq])[1:]-1
 peakdd=-draw.min()*100;stats.update(filter=r['filter'],length=int(r.length),hourly_close_max_dd_pct=peakdd)
 rows.append(stats);key=f'{r["filter"]}({r.length}) / {r.exit_rule}';series=pd.Series(eq,index=dates);curves[key]=series
 daily=series.resample('D').last().ffill();daily.to_csv(O/(key.replace('/','_').replace(' ','')+'_equity.csv'),header=['equity_NZD'])
 prev=10000.
 for year,g in daily.groupby(daily.index.year):
  last=g.iloc[-1];yearrows.append(dict(filter=r['filter'],length=int(r.length),exit_rule=r.exit_rule,year=year,return_pct=(last/prev-1)*100));prev=last
pd.DataFrame(trades).to_csv(O/'selected_trade_ledger.csv',index=False);pd.DataFrame(yearrows).to_csv(O/'selected_annual_returns.csv',index=False)
sel=pd.DataFrame(rows);sel.to_csv(O/'selected_verified_metrics.csv',index=False)
leaders=rank.groupby('exit_rule',sort=False).head(1).set_index('exit_rule').loc[order].reset_index();leaders=leaders.drop(columns=['closed_trade_max_dd_pct']).merge(sel[['filter','length','exit_rule','hourly_close_max_dd_pct']],on=['filter','length','exit_rule']);leaders.to_csv(O/'best_each_exit.csv',index=False)
plt.rcParams.update({'font.size':10});fig,axes=plt.subplots(2,1,figsize=(12,8),sharex=True)
for _,r in leaders.iterrows():
 key=f'{r["filter"]}({int(r.length)}) / {r.exit_rule}';series=curves[key].resample('D').last().ffill();label=f'{r.exit_rule}: {r["filter"]}({int(r.length)})';axes[0].plot(series.index,series,label=label);dd=series/series.cummax()-1;axes[1].plot(series.index,dd*100,label=label)
axes[0].set_yscale('log');axes[0].set_ylabel('Equity in NZD (log scale)');axes[0].legend(fontsize=8);axes[1].set_ylabel('Daily-close drawdown (%)');axes[1].set_xlabel('UTC date');fig.suptitle('AUDNZD: best in-sample combination for each exit\nTue–Thu, 17–21 signal labels | 2% risk, 2×ATR stop | zero costs')
for ax in axes:ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(O/'exit_comparison.png',dpi=160);plt.close(fig)
def table(frame,columns):
 return frame[columns].to_html(index=False,float_format=lambda x:f'{x:,.2f}',border=0)
protocol='''Signals use the existing saved filter library; no price filters are recalculated. Monthly entry thresholds are the 10th/90th percentiles of close minus filter from the preceding 12 calendar months of all available hours. Buy only below both the 10th percentile and zero; sell only above both the 90th percentile and zero. Signal bar opening labels are Tuesday, Wednesday, Thursday, 17 through 21 UTC. Enter at the next observed open only when exactly one hour follows the signal label. The signal is known only at its close. One position per independent strategy; no pyramiding. Signals whose entry would occur before the existing exit are ignored. Re-entry at an exit open is permitted when a new completed-bar signal is available.

ATR is a 20-observed-bar arithmetic average of true range, known at the signal close. The protective stop is two ATRs from entry, fixed throughout the trade. Each trade risks 2% of current realized equity at that stop: units = 0.02 × equity / stop distance. Equity is denominated in the quote currency NZD, initialized at NZD 10,000, with fractional units and no leverage cap or margin liquidation. Risk sizing is separate from the saved price filters. Gaps can lose more than 2%.

Fixed exits occur at the open 1, 2, 4 or 12 actual hours after entry, unless stopped first. If that open is absent, the position exits at the first observed open after the deadline; an active stop breached by a gap fills at that open. The MA alternative has no time cap: its target is reset each hour to the latest saved filter value from the previous bar, held constant within the hour. If the target is already crossed at the open, exit at that open. Otherwise an intrabar target touch fills at the target. When both target and stop are touched in the same H1 bar, stop takes precedence. Missing saved MA values suspend the target for that bar. Positions can cross midnight and weekends; any final position is liquidated at the sample's last close. Intrabar fill timestamps are represented by the bar end because H1 data cannot identify their exact minute.

All observed H1 bars are accepted; no completeness filter. Input period April 1, 2020–November 1, 2026; 12-month calibration means trading begins April 2021. No commission, spread, slippage or financing is included: this is a zero-cost price-series benchmark, not executable bid/ask P&L. Return includes 2% fractional-risk compounding. ATR and monthly thresholds are calculated causally; moving averages are read as saved. Rankings use full-test-period total compounded return across 34 filters × 48 lengths × 5 exits = 8,160 combinations. They are in-sample selections, not out-of-sample claims. Equivalent trade histories are flagged by fingerprints; literal top tens and distinct-history top tens are both supplied. Top-ten strategies are alternatives, not a simultaneous portfolio with 20% aggregate risk.

Drawdown in the main table is measured from hourly-close marked equity; intrabar drawdown can be worse. All-ranking files contain closed-trade drawdown, explicitly named. Equity plots use daily closes. Win rate counts strictly positive trades; profit factor R uses unweighted R gains/losses. Return rankings ignore execution capacity and margin constraints.'''
(O/'methodology.md').write_text(protocol+'\n\nPrice source: '+str(b.SOURCE)+'\nSaved filters: '+str(b.R/'close_filters'),encoding='utf-8')
html='<html><head><meta charset="utf-8"><title>AUDNZD exit comparison</title><style>body{font:16px system-ui;max-width:1200px;margin:32px auto;padding:0 20px;color:#17232d}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:8px;text-align:right;border-bottom:1px solid #ddd}th:first-child,td:first-child{text-align:left}img{max-width:100%}p{line-height:1.6}</style></head><body><h1>AUDNZD exit comparison</h1><p>2% risk per trade; zero costs. Trading April 2021–November 1, 2026. Full-sample selections.</p><h2>Best combination for each exit</h2>'+table(leaders,['exit_rule','filter','length','trades','total_return_pct','cagr_pct','hourly_close_max_dd_pct','win_rate_pct','mean_R','mean_pips','max_entry_leverage'])+'<img src="exit_comparison.png"><h2>Top ten combinations, compared across exits</h2>'+compar.pivot(index=['filter','length'],columns='exit_rule',values='total_return_pct')[order].to_html(float_format=lambda x:f'{x:,.1f}%')
for rule in order:
 q=distinct[distinct.exit_rule==rule].merge(sel[['filter','length','exit_rule','hourly_close_max_dd_pct']],on=['filter','length','exit_rule']);html+=f'<h2>{rule}: top ten distinct trade histories</h2>'+table(q,['filter','length','trades','total_return_pct','hourly_close_max_dd_pct','win_rate_pct','mean_R','mean_pips'])
html+='<h2>Rules and limitations</h2>'+''.join('<p>'+s+'</p>' for s in protocol.split('\n\n'))+'</body></html>'
(O/'report.html').write_text(html,encoding='utf-8')
(O/'verification.json').write_text(json.dumps({'selected_runs_reproduced':len(sel),'trade_ledgers_verified':len(trades),'expected_configurations':8160,'actual_configurations':len(d),'future_invariance_test':'passed','execution_unit_tests':'passed','filter_recalculation':False},indent=2))
with zipfile.ZipFile(O/'AUDNZD_strategy_results.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in O.iterdir():
  if f.suffix in ['.csv','.json','.md','.html','.png']:z.write(f,f.name)
print(leaders[['exit_rule','filter','length','trades','total_return_pct','cagr_pct','hourly_close_max_dd_pct','mean_pips','max_entry_leverage']].to_string(index=False))
