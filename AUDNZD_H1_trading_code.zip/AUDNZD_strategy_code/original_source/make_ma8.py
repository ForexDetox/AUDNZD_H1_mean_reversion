from pathlib import Path
s=Path('work/window8_curves.py').read_text(encoding='utf-8')
s=s.replace("b.O/'window8_1bp'","b.O/'window8_MA_1bp'").replace('for h in b.H:','for h in [0]:').replace('all_170_rankings.csv','all_34_MA_rankings.csv')
s=s.replace("axes[0].set_yscale('log');axes[0].set_ylabel('Equity in NZD (log scale)')","axes[0].set_ylim(bottom=0);axes[0].yaxis.set_major_formatter(matplotlib.ticker.StrMethodFormatter('{x:,.0f}'));axes[0].set_ylabel('Equity in NZD (linear scale)')")
s=s.replace('AUDNZD: top 10 equity curves with an 8-bar filter window','AUDNZD: top 10 filters, MA exit, window length 8')
s=s.replace('170 filter/exit combinations','34 filters with MA exit').replace('AUDNZD_top10_window8.{ext}','AUDNZD_top10_MA_window8_linear.{ext}').replace('AUDNZD_window8_results.zip','AUDNZD_MA_window8_results.zip')
s=s.replace('All 34 filters and exits 1h, 2h, 4h, 12h and MA were evaluated (170 combinations).','All 34 filters were evaluated using the MA exit only (34 combinations). The target updates hourly to the previous completed bar\'s saved filter value, with no fixed time limit. Stop takes precedence if both stop and target are touched in the same bar.'.replace("bar's","bar’s"))
s=s.replace('Different exit rules for the same filter may appear.','Every plotted curve uses MA exit.').replace('all 170 prior gross ending equities','all 34 prior gross ending equities')
Path('work/ma8_curves.py').write_text(s,encoding='utf-8')
